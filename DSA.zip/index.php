<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 3.2//EN">
<!--defining the code to be HTML-->
<HTML>
	<meta charset="UTF-8">
	
	<HEAD>
	<!-- defining CSS file to be used as a stylesheet-->
			<link href="site.css" rel="stylesheet">
	<!-- Course information-->
			<META NAME="course" CONTENT="GN52">
			<META NAME="award" CONTENT="BSc/ITManForBus">
			<META NAME="type" CONTENT="student">
	<!-- Please do not remove the above tags -->
	
	<!--Title in the web browser's tab -->
			<TITLE>DSA Assignment site</TITLE>
	</HEAD>
	
	
	<BODY>
		<!--Header-->
		<H1>DSA Assignment site</H1>
		
		<div class="box">
		<!--iframe for Milan.  Defining its size and allignment-->
		<iframe src="Milan.php" name="testframe" frameborder="0" scrolling="no" width="50%" height="3500px" align="left"> </iframe> </div>

		<div class="box">
		<!--iframe for Melbourne.  Defining its size and allignment-->
		<iframe src="Melbourne.php" name="testframe" frameborder="0" scrolling="no" width="50%" height="3700px" align="right"> </iframe> </div>
		
		<!--Credits-->
		© Rafal, Patryk, Filip, Matthew 2015-16

		</BODY>

</HTML>
<!--END OF THE CODE-->