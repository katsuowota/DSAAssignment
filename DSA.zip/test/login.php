<?php
$host="mysql5";
$username="fet14011094";
$password="PDFP22u2";
$database="fet14011094";
$connection = mysql_connect($host,$username,$password,$database);
?>